import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { SortpipeComponent } from './sortpipe/sortpipe.component';
import { OrderbyPipe } from './sort/orderby.pipe';
import { PipeComponent } from './pipe/pipe.component';
import { DirectiveComponent } from './directive/directive.component';
import { RedDirective } from './red.directive';



@NgModule({
  declarations: [
    AppComponent,
    SortpipeComponent,
    OrderbyPipe,
    PipeComponent,
    DirectiveComponent,
    RedDirective,
  ],
  imports: [
    BrowserModule, FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
