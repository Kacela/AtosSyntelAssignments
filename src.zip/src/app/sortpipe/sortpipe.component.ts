import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sortpipe',
   templateUrl: './sortpipe.component.html',
   styleUrls: ['./sortpipe.component.css']
})
export class SortpipeComponent implements OnInit {
  rows=5;
  sortby: string = 'asc';

  //event handler for the select element's change event
  selectChangeHandler (event: any) {
    //update the ui
    this.sortby = event.target.value;
  }
  employees = [
    {
      id: 101,
      name: "Tom Hanks",
      salary: 1500000,
      city:"Seattle",
      age: 66,
      dob: new Date("May 31,1953"),
      mobile:"8093843101"
    },
    {
      id: 102,
      name: "Tom Cruise",
      salary: 1250000,
      city:"New York",
      age: 59,
      dob: new Date("January 12,1961"),
      mobile:"7021840101"
    },
    {
      id: 103,
      name: "Lily Salvatore",
      salary: 200000,
      city:"Minnesota",
      age: 47,
      dob: new Date("October 30,1972"),
      mobile:"8753822201"
    },
    {
      id: 104,
      name: "Ashley Bennet",
      salary: 500000,
      city:"Portland",
      age: 33,
      dob: new Date("September 27,1986"),
      mobile:"9993443156"
    },
    {
      id: 105,
      name: "Nick Jonas",
      salary: 300000,
      city:"London",
      age: 27,
      dob: new Date("November 5,1992"),
      mobile:"8284811101"
    }
  ];
  showSelectValue(){
    console.log("Selected:",this.sortby);
  }
  constructor() { }
  
  ngOnInit(): void {
  }

}
