import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SortpipeComponent } from './sortpipe.component';

describe('SortpipeComponent', () => {
  let component: SortpipeComponent;
  let fixture: ComponentFixture<SortpipeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SortpipeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SortpipeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
