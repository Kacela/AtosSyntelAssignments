import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from '../home/home.component';
import { SortpipeComponent } from '../sortpipe/sortpipe.component';
import { PipeComponent } from '../pipe/pipe.component';
import { DirectiveComponent } from '../directive/directive.component';
import { ServicedemoComponent } from '../servicedemo/servicedemo.component';
import { EmployeedemoComponent } from '../employeedemo/employeedemo.component';
import { TemplateComponent } from '../template/template.component';
import { ReactiveComponent } from '../reactive/reactive.component';
import { HttpclientdemoComponent } from '../httpclientdemo/httpclientdemo.component';
import { AnimationComponent } from '../animation/animation.component';

const routes: Routes = [
  {path:'home',component:HomeComponent},
  {path:'animate',component:AnimationComponent},
  {path:'sortpipe',component:SortpipeComponent},
  {path:'pipe',component:PipeComponent},
  {path:'directive',component:DirectiveComponent},
  {path:'servicedemo',component:ServicedemoComponent},
  {path:'employeedemo' ,component:EmployeedemoComponent},
  {path:'template',component:TemplateComponent },
  {path:'reactive',component:ReactiveComponent},
  {path:'httpclient',component:HttpclientdemoComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
