import { Component, OnInit } from '@angular/core';
import { DateService } from '../date/date.service';
@Component({
  selector: 'app-servicedemo',
  templateUrl: './servicedemo.component.html',
  styleUrls: ['./servicedemo.component.css']
})
export class ServicedemoComponent implements OnInit {

  todaydate; 
  constructor(private myservice: DateService) { }
  ngOnInit() { 
     this.todaydate = this.myservice.showTodayDate(); 
  }

}
