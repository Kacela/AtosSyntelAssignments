import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
 
  emps=[
    {id:101,name:"Kacela D'Silva",salary:28333,city:"Thane"},    

    {id:102,name:"Sharvari Shanbhag",salary:25000,city:"Mumbai"},

    {id:103,name:"Sameeskha Dalvi",salary:35000,city:"Mumbai"},

    {id:104,name:"Clary",salary:50000,city:"North York"},  
  ];
  public getAllEmployees(): any[]{
    return this.emps;
  } 

  // httpclient service
  private finaldata = [];
   private apiurl = "http://jsonplaceholder.typicode.com/users";
   constructor(private http: HttpClient) { }
   getData() {
      return this.http.get(this.apiurl);
   }
}
