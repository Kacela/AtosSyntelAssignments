import { Component, OnInit } from '@angular/core';
import {EmployeeService} from '../employee/employee.service'

@Component({
  selector: 'app-httpclientdemo',
  templateUrl: './httpclientdemo.component.html',
  styleUrls: ['./httpclientdemo.component.css']
})
export class HttpclientdemoComponent implements OnInit {
  public userdata = [];
  id:number;
  name:string;
  phone:string;
  website:string;
  addmodel:any={};
  editmodel:any={};
  isEditClicked: boolean = false ;
  isAddClicked: boolean = true ;
  uid;
  constructor(private emp:EmployeeService) {}

  ngOnInit(): void {
    this.emp.getData().subscribe((data) => {
      this.userdata = Array.from(Object.keys(data), k=>data[k]);
   });
  }
  deleteUserById(id:number){
    console.log('delete'+id);
    this.userdata.splice(id, 1);     
  }
  editUserById(i:number){
    this.editmodel.id=this.userdata[i].id;
    this.editmodel.name=this.userdata[i].name;
    this.editmodel.phone=this.userdata[i].phone;
    this.editmodel.website=this.userdata[i].website;
    this.uid=i;
    this.isEditClicked=true;
    this.isAddClicked=false;
  }
  updateUser(){
    let x=this.uid;
    for(let i=0;i<this.userdata.length;i++)
    {
      if (i==x)
      {
        this.userdata[i]=this.editmodel;
        this.editmodel={}
      }
    }
    this.isEditClicked=false;
    this.isAddClicked=true;
  }
  addUser(){
    this.userdata.push(this.addmodel)
    this.addmodel={};
  }
  cancel(){
    this.editmodel={};
    this.isEditClicked=false;
    this.isAddClicked=true;
  }
}
