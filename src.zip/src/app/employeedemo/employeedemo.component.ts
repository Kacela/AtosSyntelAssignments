import { Component, OnInit } from '@angular/core';
import {EmployeeService} from '../employee/employee.service'
@Component({
  selector: 'app-employeedemo',
  templateUrl: './employeedemo.component.html',
  styleUrls: ['./employeedemo.component.css']
})
export class EmployeedemoComponent implements OnInit {
  employees:any[];
  message=""; 
  //employee:Employee;
  id:number;
  name:string;
  salary:number;
  city:string;
  model:any={};
  model2:any={};
  isShown: boolean = false ;
  constructor(em:EmployeeService) {
    this.emps=em.getAllEmployees();
   }
   emps:any=[];
  getAllEmployees():any[]{
    console.log("in get all employees");
    return this.emps;
  }
  getEmployeeById(id:number){
    console.log(id);  
  }
  ngOnInit(): void {
  }
  deleteEmployeeById(id:number){
    console.log('delete'+id)
this.emps.splice(id, 1);  //index,length
 //this.getAllEmployees();
     
        }
  myValue;
        editEmployeeById(k:number){
          this.model2.id=this.emps[k].id;
          this.model2.name=this.emps[k].name;
          this.model2.salary=this.emps[k].salary;
          this.model2.city=this.emps[k].city;
          this.myValue=k;
          this.isShown=true;
          }
          updateEmployee()
          {
            console.log("in update");
            let k=this.myValue;
            for(let i=0;i<this.emps.length;i++)
            {
              if (i==k)
              {
                this.emps[i]=this.model2;
                 this.model2={}
              }
            }
            this.isShown=false;
          }

          addEmployee(){
         console.log("in add")
       // this.employee={this.emps,name:"Ayansh Mane",salary:32342.44554,city:"Solapur"};
       // this.emps.push(new Employee(this.id,this.name,this.salary,this.city));
       this.emps.push(this.model)
       this.model={};

       }
}
