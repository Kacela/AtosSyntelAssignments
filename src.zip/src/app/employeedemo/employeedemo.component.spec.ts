import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeedemoComponent } from './employeedemo.component';

describe('EmployeedemoComponent', () => {
  let component: EmployeedemoComponent;
  let fixture: ComponentFixture<EmployeedemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeedemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeedemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
