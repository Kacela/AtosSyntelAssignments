import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-reactive',
  templateUrl: './reactive.component.html',
  styleUrls: ['./reactive.component.css']
})
export class ReactiveComponent implements OnInit {
  userForm = new FormGroup({  
    firstName: new FormControl('Guest',[Validators.required,Validators.minLength(4),Validators.maxLength(10)]),  
    email: new FormControl(null,Validators.pattern('[^ @]*@[^ @]*')),  
    address: new FormGroup({  
        country: new FormControl(),  
        city: new FormControl(),  
        postalCode: new FormControl(null,Validators.pattern('^[1-9][0-9]{4}$'))  
    })  
});  

submitForm() {  
    console.log(this.userForm.value);  
}  

  constructor() { }

  ngOnInit(): void {
  }

}
