import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
  name: 'orderby'
})
export class OrderbyPipe implements PipeTransform {
  transform(value: Array <any>, args?:any):any{
    let order = args;
   return value.sort((a,b)=>{
     if(order=="Nasc"){
     let x= a.name.toLowerCase();
     let y= b.name.toLowerCase();
     if(x<y){
       return -1;
     } else {
       return 1;
     }
     return 0;
    }
    else if(order=='Ndesc'){
     let x= a.name.toLowerCase();
     let y= b.name.toLowerCase();
     if(x>y){
       return -1;
     } else {
       return 1;
     }
     return 0;
    }
    else if(order=='Aasc'){
      let x= a.age;
      let y= b.age;
      if(x<y){
        return -1;
      } else {
        return 1;
      }
      return 0;
     }
     else if(order=='Adesc'){
      let x= a.age;
      let y= b.age;
      if(x>y){
        return -1;
      } else {
        return 1;
      }
      return 0;
     }
   });

  }

}
