import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'orderby'
})
export class OrderbyPipe implements PipeTransform {

  transform(value: any):any{
    switch(value){
      case "asc":return value.sort();
      case "desc":return value.sort().reverse();
         
    }

  }

}
