import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appRed]'
})
export class RedDirective {

  constructor(e:ElementRef) { 
    e.nativeElement.style.color='red';
    e.nativeElement.style.border= '5px solid maroon';
  }

}
