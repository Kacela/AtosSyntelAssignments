import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipe',
  templateUrl: './pipe.component.html',
  styleUrls: ['./pipe.component.css']
})
export class PipeComponent implements OnInit {
  name="Kacela dsilva";
  location="Mumbai";
  salary=24083.00
  doj= new Date("March 16,2020");
  constructor() { }

  ngOnInit(): void {
  }

}
